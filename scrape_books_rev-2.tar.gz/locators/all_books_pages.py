class AllBooksPageLocator:
    Books = 'div.col-sm-8 section ol.row li.col-xs-6'
    PAGER = 'section ul.pager li.current'