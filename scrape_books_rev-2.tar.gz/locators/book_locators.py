class BookLocators:
    Title_Locator = 'article.product_pod h3 a'
    Link_Locator = 'article.product_pod h3 a'
    Price_Locator = 'article.product_pod div.product_price p.price_color'
    Rating_Locator = 'article.product_pod p.star-rating'
